from flask_login import UserMixin
import sqlite3

class User(UserMixin):
    def __init__(self, id, name, email):
      self.id = id
      self.name = name
      self.email = email
    
    @staticmethod
    def get(id):
      connection = sqlite3.connect("database.db")
      cursor = connection.cursor()
      results = cursor.execute(
      "SELECT id, name, email FROM users WHERE name = ?",
      (id,),).fetchone()
      connection.commit()
      connection.close()
      if not results:
        return None

      return User(results[0], results[1], results[2])

    @staticmethod
    def create(id, name, email):
      connection = sqlite3.connect("database.db")
      cursor = connection.cursor()
      cursor.execute("INSERT INTO users VALUES (?, ?, ?)", [id, name, email])
      connection.commit()
      connection.close()
    