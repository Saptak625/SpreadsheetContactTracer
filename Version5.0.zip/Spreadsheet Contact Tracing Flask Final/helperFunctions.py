import qrcode
from openpyxl import load_workbook
import os

ROOT_PATH = "https://127.0.0.1:5000/"

#Code to create new spreadsheet
# wb = Workbook()
# wb.save(filename="attendence.xlsx")

# # Data can be assigned directly to cells
# ws['A1'] = 42
#QR Code Generator
def generateQRCode(msg, filename):
  img = qrcode.make(msg)
  img.save(filename)

#Excel Editor
def editSpreadsheet(cell, value):
  workbook = load_workbook(filename="attendence.xlsx")
  sheet = workbook.active
  sheet[cell] = value

# classroomName = "Krause4"
# numOfSeats = 3
