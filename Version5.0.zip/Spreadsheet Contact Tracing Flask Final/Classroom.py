from dbFunctions import addClassroom, queryByName, fetchAllEntries
import sys

class Classroom:
    def __init__(self, name, numOfSeats, owner, from_database = False):
        self.name = name
        self.numOfSeats = numOfSeats
        self.owner = owner
        if not from_database:
            self.addToDatabase()

    def addToDatabase(self):
        addClassroom(self)
        
    def generateQRCodes():
        newpath = f'{self.name}' 
        if not os.path.exists(newpath):
            os.makedirs(newpath)
        for i in range(self.numOfSeats):
            generateQRCode(f"{ROOT_PATH}recordentry?classroom={self.name}&seat={i+1}", f"QRCodeFolder/{self.name}/{self.name}_{i+1}.png")
        return f"{ROOT_PATH}recordentry?classroom={self.name}&seat={i+1}", f"QRCodeFolder/{self.name}"

