import sqlite3

def init_db_local():
    #Creating and Initialing Table(Only execute once)
    connection = sqlite3.connect("sqlite_db")
    cursor = connection.cursor()
    cursor.execute("CREATE TABLE classrooms (name TEXT, numOfSeats INTEGER, owner TEXT)")
    cursor.execute("CREATE TABLE entries (name TEXT, classroomid TEXT, deskNumber INTEGER, time TEXT)")

def addClassroom(classroom):
    connection = sqlite3.connect("sqlite_db")
    cursor = connection.cursor()
    cursor.execute("INSERT INTO classrooms VALUES (?, ?, ?)", [classroom.name, classroom.numOfSeats, classroom.owner.email])
    connection.commit()
    connection.close()

def queryByName(queryName):
    connection = sqlite3.connect("sqlite_db")
    cursor = connection.cursor()
    results = cursor.execute(
    "SELECT name, numOfSeats, owner FROM classrooms WHERE name = ?",
    (queryName,),).fetchone()
    connection.commit()
    connection.close()
    return results

def fetchAllEntries():
    connection = sqlite3.connect("sqlite_db")
    cursor = connection.cursor()
    rows = cursor.execute("SELECT name, numOfSeats, owner FROM classrooms").fetchall()
    connection.commit()
    connection.close()
    return rows
 