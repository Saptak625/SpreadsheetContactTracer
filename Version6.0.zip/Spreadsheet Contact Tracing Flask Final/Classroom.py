from dbFunctions import addClassroom, queryByName, fetchAllEntries
import sys
import os
from helperFunctions import generateQRCode

class Classroom:
    def __init__(self, name, numOfSeats, owner, from_database = False):
        self.name = name
        self.numOfSeats = numOfSeats
        self.owner = owner
        if not from_database:
            self.addToDatabase()

    def addToDatabase(self):
        addClassroom(self)
        
    def generateQRCodes(self):
        ROOT_PATH = "https://127.0.0.1:5000/"
        newpath = f'QRCodeFolder/{self.name}' 
        if not os.path.exists(newpath):
            os.makedirs(newpath)
        for i in range(self.numOfSeats):
            generateQRCode(f"{ROOT_PATH}recordentry?classroom={self.name}&seat={i+1}", f"{newpath}/{self.name}_{i+1}.png")
        return f"QRCodeFolder/{self.name}"

