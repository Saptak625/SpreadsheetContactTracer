from dbFunctions import addClassroom, queryByName, fetchAllEntries
import sys

class Classroom:
    def __init__(self, name, numOfSeats, owner, from_database = False):
        self.name = name
        self.numOfSeats = numOfSeats
        self.owner = owner
        if not from_database:
            self.addToDatabase()

    def addToDatabase(self):
        addClassroom(self)

    def generateQRCodes():
        print("Generating QR Codes")
