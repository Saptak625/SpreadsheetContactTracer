from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, DecimalField, IntegerField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError

from dbFunctions import queryByName

class CreateNewClassroomForm(FlaskForm):
    name = StringField('Name Of Class: ', validators=[DataRequired()])
    numOfSeats = IntegerField('Number of Seats: ', validators=[DataRequired()])
    submit = SubmitField('Submit')

    def validate_name(form, field):
        queryResults=queryByName(field.data)
        print(queryResults, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>....")
        # if queryResults != None:
        #     raise ValidationError("Name must be unique.")